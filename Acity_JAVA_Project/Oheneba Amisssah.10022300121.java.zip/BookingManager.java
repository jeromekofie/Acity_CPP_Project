import java.util.Vector;

public class BookingManager {
    public Vector<Room> rooms = new Vector<>();
    public Vector<Customer> customers = new Vector<>();
    private DatabaseManager db;

    public BookingManager() {
        db = new DatabaseManager();
        loadRoomsFromDB();
        loadCustomersFromDB();
    }

    public void addCustomer(Customer c) {
        customers.add(c);
        db.addCustomer(c);
    }

    public void bookRoom(int roomNumber) {
        for (Room r : rooms) {
            if (r.getRoomNumber() == roomNumber) {
                r.setBooked(true);
                break;
            }
        }
        db.bookRoom(roomNumber);
    }

    public void unbookRoom(int roomNumber) {
        for (Room r : rooms) {
            if (r.getRoomNumber() == roomNumber) {
                r.setBooked(false);
                break;
            }
        }
        db.unbookRoom(roomNumber);
    }

    private void loadRoomsFromDB() {
        rooms = db.getAllRooms();
    }

    private void loadCustomersFromDB() {
        customers = db.getAllCustomers();
    }
}
