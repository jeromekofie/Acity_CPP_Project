import java.sql.*;
import java.util.Vector;

public class DatabaseManager {
    private Connection conn;

    public DatabaseManager() {
        try {
            // Load MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel_db", "root", "Lebron1234$");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Vector<Room> getAllRooms() {
        Vector<Room> rooms = new Vector<>();
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM rooms");
            while (rs.next()) {
                int roomNumber = rs.getInt("room_number");
                boolean isBooked = rs.getBoolean("is_booked");
                Room room = new Room(roomNumber);
                room.setBooked(isBooked);
                rooms.add(room);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rooms;
    }

    public Vector<Customer> getAllCustomers() {
        Vector<Customer> customers = new Vector<>();
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM customers");
            while (rs.next()) {
                int reservationId = rs.getInt("reservation_id");
                String name = rs.getString("name");
                String checkIn = rs.getString("check_in_date");
                String checkOut = rs.getString("check_out_date");
                int roomNumber = rs.getInt("room_number");

                Customer customer = new Customer(reservationId, name, checkIn, checkOut, roomNumber);
                customers.add(customer);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return customers;
    }

    public void bookRoom(int roomNumber) {
        try {
            PreparedStatement ps = conn.prepareStatement("UPDATE rooms SET is_booked = ? WHERE room_number = ?");
            ps.setBoolean(1, true);
            ps.setInt(2, roomNumber);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void unbookRoom(int roomNumber) {
        try {
            PreparedStatement ps = conn.prepareStatement("UPDATE rooms SET is_booked = ? WHERE room_number = ?");
            ps.setBoolean(1, false);
            ps.setInt(2, roomNumber);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addCustomer(Customer c) {
        try {
            PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO customers (name, check_in_date, check_out_date, room_number) VALUES (?, ?, ?, ?)");
            ps.setString(1, c.getName());
            ps.setString(2, c.getCheckInDate());
            ps.setString(3, c.getCheckOutDate());
            ps.setInt(4, c.getRoomNumber());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateCustomer(Customer c) {
        try {
            PreparedStatement ps = conn.prepareStatement(
                "UPDATE customers SET name = ?, check_in_date = ?, check_out_date = ?, room_number = ? WHERE reservation_id = ?");
            ps.setString(1, c.getName());
            ps.setString(2, c.getCheckInDate());
            ps.setString(3, c.getCheckOutDate());
            ps.setInt(4, c.getRoomNumber());
            ps.setInt(5, c.getReservationId());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteCustomer(int reservationId) {
        try {
            // First get the room number to unbook it
            PreparedStatement getRoom = conn.prepareStatement("SELECT room_number FROM customers WHERE reservation_id = ?");
            getRoom.setInt(1, reservationId);
            ResultSet rs = getRoom.executeQuery();
            if (rs.next()) {
                int roomNumber = rs.getInt("room_number");
                unbookRoom(roomNumber); // Set room as available again
            }

            // Now delete the customer
            PreparedStatement ps = conn.prepareStatement("DELETE FROM customers WHERE reservation_id = ?");
            ps.setInt(1, reservationId);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
