import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class HotelMainframe extends JFrame {
    DatabaseManager manager = new DatabaseManager();  // Connect to the database
    JTextArea displayArea;

    public HotelMainframe() {
        setTitle("Hotel Booking App");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setContentPane(new BackgroundPanel("hotelbackgroundimage.png"));
        setLayout(null);

        JLabel titleLabel = new JLabel("Hotel Booking App");
        titleLabel.setFont(new Font("Serif", Font.BOLD, 26));
        titleLabel.setForeground(Color.YELLOW);
        titleLabel.setBounds(280, 10, 300, 40);
        add(titleLabel);

        // Input fields and labels
        JLabel roomTypeLabel = new JLabel("ROOM TYPE:");
        roomTypeLabel.setBounds(50, 70, 100, 25);
        roomTypeLabel.setForeground(Color.WHITE);
        add(roomTypeLabel);

        JComboBox<String> roomTypeCombo = new JComboBox<>(new String[]{"SINGLE", "DOUBLE", "DELUXE"});
        roomTypeCombo.setBounds(160, 70, 150, 25);
        add(roomTypeCombo);

        JTextField reservationIdField = createInput("RESERVATION ID:", 110);
        JTextField nameField = createInput("NAME:", 150);
        JTextField roomField = createInput("ROOM NUMBER:", 190);
        JTextField checkInField = createInput("CHECK-IN DATE:", 230);
        JTextField checkOutField = createInput("CHECK-OUT DATE:", 270);
        JTextField amountField = createInput("AMOUNT:", 310);

        JLabel paymentLabel = new JLabel("PAYMENT METHOD:");
        paymentLabel.setBounds(50, 350, 150, 25);
        paymentLabel.setForeground(Color.WHITE);
        add(paymentLabel);

        JComboBox<String> paymentCombo = new JComboBox<>(new String[]{"VISA CARD", "MASTER CARD", "CASH"});
        paymentCombo.setBounds(200, 350, 150, 25);
        add(paymentCombo);

        JButton searchButton = new JButton("SEARCH");
        searchButton.setBounds(50, 450, 150, 40);
        searchButton.setBackground(Color.CYAN);
        add(searchButton);

        searchButton.addActionListener(e -> {
            String reservationId = reservationIdField.getText();
            JOptionPane.showMessageDialog(this, "Searching for Reservation ID: " + reservationId);
        });

        JButton bookButton = new JButton("BOOK");
        bookButton.setBounds(300, 400, 150, 40);
        bookButton.setBackground(Color.YELLOW);
        add(bookButton);

        // NEW: Update Button
        JButton updateButton = new JButton("UPDATE");
        updateButton.setBounds(300, 450, 150, 40);
        updateButton.setBackground(Color.ORANGE);
        add(updateButton);

        // NEW: Delete Button
        JButton deleteButton = new JButton("DELETE");
        deleteButton.setBounds(550, 450, 150, 40);
        deleteButton.setBackground(Color.RED);
        add(deleteButton);

        // Display area
        displayArea = new JTextArea();
        displayArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(displayArea);
        scrollPane.setBounds(400, 70, 350, 370);
        add(scrollPane);

        // Booking logic connected to database
        bookButton.addActionListener(e -> {
            try {
                String name = nameField.getText();
                String checkIn = checkInField.getText();
                String checkOut = checkOutField.getText();
                int roomNo = Integer.parseInt(roomField.getText());

                Customer customer = new Customer(name, checkIn, checkOut, roomNo);
                manager.addCustomer(customer);     // Insert into DB
                manager.bookRoom(roomNo);          // Mark room as booked in DB

                JOptionPane.showMessageDialog(this, "Booking Successful!");
                updateDisplay();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid input: " + ex.getMessage());
            }
        });

        // UPDATE logic
        updateButton.addActionListener(e -> {
            try {
                int reservationId = Integer.parseInt(reservationIdField.getText());
                String name = nameField.getText();
                String checkIn = checkInField.getText();
                String checkOut = checkOutField.getText();
                int roomNo = Integer.parseInt(roomField.getText());

                Customer customer = new Customer(reservationId, name, checkIn, checkOut, roomNo);
                manager.updateCustomer(customer);  // Update in DB

                JOptionPane.showMessageDialog(this, "Update Successful!");
                updateDisplay();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Update Failed: " + ex.getMessage());
            }
        });

        // DELETE logic
        deleteButton.addActionListener(e -> {
            try {
                int reservationId = Integer.parseInt(reservationIdField.getText());
                manager.deleteCustomer(reservationId);  // Delete from DB

                JOptionPane.showMessageDialog(this, "Delete Successful!");
                updateDisplay();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Delete Failed: " + ex.getMessage());
            }
        });

        updateDisplay();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

    private JTextField createInput(String label, int y) {
        JLabel jLabel = new JLabel(label);
        jLabel.setBounds(50, y, 150, 25);
        jLabel.setForeground(Color.WHITE);
        add(jLabel);

        JTextField textField = new JTextField();
        textField.setBounds(200, y, 150, 25);
        add(textField);

        return textField;
    }

    private void updateDisplay() {
        displayArea.setText("Current Bookings:\n");
        for (Customer c : manager.getAllCustomers()) {
            displayArea.append(c + "\n");
        }

        displayArea.append("\nRooms:\n");
        for (Room r : manager.getAllRooms()) {
            displayArea.append(r + "\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(HotelMainframe::new);
    }

    // Background panel
    class BackgroundPanel extends JPanel {
        private Image backgroundImage;

        public BackgroundPanel(String path) {
            try {
                backgroundImage = new ImageIcon(getClass().getResource(path)).getImage();
            } catch (Exception e) {
                System.out.println("Background image not found.");
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        }
    }
}
