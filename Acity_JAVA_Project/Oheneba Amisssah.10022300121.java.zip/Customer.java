import java.io.Serializable;

public class Customer implements Serializable {
    private int reservationId;
    private String name;
    private String checkInDate;
    private String checkOutDate;
    private int roomNumber;

    // Constructor for new bookings (no reservation ID yet)
    public Customer(String name, String checkIn, String checkOut, int roomNumber) {
        this.name = name;
        this.checkInDate = checkIn;
        this.checkOutDate = checkOut;
        this.roomNumber = roomNumber;
    }

    // Constructor for existing bookings (with reservation ID)
    public Customer(int reservationId, String name, String checkIn, String checkOut, int roomNumber) {
        this.reservationId = reservationId;
        this.name = name;
        this.checkInDate = checkIn;
        this.checkOutDate = checkOut;
        this.roomNumber = roomNumber;
    }

    // Getters
    public int getReservationId() { return reservationId; }
    public String getName() { return name; }
    public String getCheckInDate() { return checkInDate; }
    public String getCheckOutDate() { return checkOutDate; }
    public int getRoomNumber() { return roomNumber; }

    // Setters
    public void setReservationId(int reservationId) { this.reservationId = reservationId; }
    public void setName(String name) { this.name = name; }
    public void setCheckInDate(String checkInDate) { this.checkInDate = checkInDate; }
    public void setCheckOutDate(String checkOutDate) { this.checkOutDate = checkOutDate; }
    public void setRoomNumber(int roomNumber) { this.roomNumber = roomNumber; }

    @Override
    public String toString() {
        return "ID: " + reservationId + " | " + name + " | Room " + roomNumber + " | " + checkInDate + " to " + checkOutDate;
    }
}
