import java.io.Serializable;

public class Room implements Serializable {
    // private int roomNumber;
    // private boolean isBooked;


    public int roomNumber; 
    public boolean isBooked;

    public Room(int roomNumber) {
        this.roomNumber = roomNumber;
        this.isBooked = false;
    }

    public int getRoomNumber() { return roomNumber; }
    public boolean isBooked() { return isBooked; }

    public void setBooked(boolean booked) {
        isBooked = booked;
    }

    // public void getInt() {
        
    // }

    // public void getint () {
        
    // }


    @Override
    public String toString() {
        return "Room " + roomNumber + " - " + (isBooked ? "Booked" : "Available");
    }
}


