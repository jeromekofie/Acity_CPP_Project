import java.awt.*;
import java.util.List;
import javax.swing.*;


public class Main {
    private static JTextField nameField;
    private static JTextField phoneField;
    private static DefaultListModel<Contact> listModel;
    private static JList<Contact> contactList;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            DBHelper.initDB();
            createAndShowGUI();
        });
    }

    private static void createAndShowGUI() {
        JFrame frame = new JFrame("Contact Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 500);
        frame.setLocationRelativeTo(null);

        BackgroundPanel backgroundPanel = new BackgroundPanel();
        backgroundPanel.setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        inputPanel.setOpaque(false);
        nameField = new JTextField();
        phoneField = new JTextField();
        inputPanel.add(new JLabel("Name:"));
        inputPanel.add(nameField);
        inputPanel.add(new JLabel("Phone:"));
        inputPanel.add(phoneField);
        backgroundPanel.add(inputPanel, BorderLayout.NORTH);

        listModel = new DefaultListModel<>();
        contactList = new JList<>(listModel);
        JScrollPane scrollPane = new JScrollPane(contactList);
        backgroundPanel.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setOpaque(false);
        addButtons(buttonPanel);
        backgroundPanel.add(buttonPanel, BorderLayout.SOUTH);

        refreshContactList();

        frame.setContentPane(backgroundPanel);
        frame.setVisible(true);
    }

    private static void addButtons(JPanel panel) {
        JButton addButton = new JButton("Add");
        JButton updateButton = new JButton("Update");
        JButton deleteButton = new JButton("Delete");
        JButton sortByNameButton = new JButton("Sort by Name");
        JButton sortByPhoneButton = new JButton("Sort by Phone");
        JButton saveToFileButton = new JButton("Save to File");

        panel.add(addButton);
        panel.add(updateButton);
        panel.add(deleteButton);
        panel.add(sortByNameButton);
        panel.add(sortByPhoneButton);
        panel.add(saveToFileButton);

        addButton.addActionListener(e -> {
            String name = nameField.getText().trim();
            String phone = phoneField.getText().trim();
            if (!name.isEmpty() && !phone.isEmpty()) {
                if (ContactManager.addContact(new Contact(name, phone))) {
                    refreshContactList();
                    nameField.setText("");
                    phoneField.setText("");
                }
            }
        });

        updateButton.addActionListener(e -> {
            Contact selected = contactList.getSelectedValue();
            String newPhone = phoneField.getText().trim();
            if (selected != null && !newPhone.isEmpty()) {
                if (ContactManager.updateContact(selected.getName(), newPhone)) {
                    refreshContactList();
                    phoneField.setText("");
                }
            }
        });

        deleteButton.addActionListener(e -> {
            Contact selected = contactList.getSelectedValue();
            if (selected != null) {
                if (ContactManager.deleteContact(selected.getName())) {
                    refreshContactList();
                }
            }
        });

        sortByNameButton.addActionListener(e -> {
            List<Contact> contacts = ContactManager.sortByName(ContactManager.getAllContacts());
            updateContactList(contacts);
        });

        sortByPhoneButton.addActionListener(e -> {
            List<Contact> contacts = ContactManager.sortByPhone(ContactManager.getAllContacts());
            updateContactList(contacts);
        });

        saveToFileButton.addActionListener(e -> ContactManager.saveToFile());
    }

    private static void refreshContactList() {
        List<Contact> contacts = ContactManager.getAllContacts();
        updateContactList(contacts);
    }

    private static void updateContactList(List<Contact> contacts) {
        listModel.clear();
        for (Contact c : contacts) {
            listModel.addElement(c);
        }
    }
}
