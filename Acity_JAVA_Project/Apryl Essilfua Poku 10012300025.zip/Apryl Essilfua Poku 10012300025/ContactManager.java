import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.logging.*;
import javax.swing.*;

public class ContactManager  {
    private static final String FILE_PATH = "data/contacts.txt";
    private static final Logger logger = Logger.getLogger(ContactManager.class.getName());

    public static boolean addContact(Contact contact) {
        if (isDuplicate(contact.getName())) {
            JOptionPane.showMessageDialog(null, "Contact already exists.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        String sql = "INSERT INTO contacts(name, phone) VALUES(?, ?)";
        try (Connection conn = DBHelper.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, contact.getName());
            pstmt.setString(2, contact.getPhone());
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace(); // For debug
            logger.log(Level.SEVERE, "Error adding contact: " + contact, e);
            return false;
        }
    }

    public static boolean updateContact(String name, String newPhone) {
        String sql = "UPDATE contacts SET phone = ? WHERE name = ?";
        try (Connection conn = DBHelper.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, newPhone);
            pstmt.setString(2, name);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            logger.log(Level.SEVERE, "Error updating contact", e);
            return false;
        }
    }

    public static boolean deleteContact(String name) {
        String sql = "DELETE FROM contacts WHERE name = ?";
        try (Connection conn = DBHelper.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            logger.log(Level.SEVERE, "Error deleting contact", e);
            return false;
        }
    }

    public static List<Contact> getAllContacts() {
        List<Contact> list = new ArrayList<>();
        String sql = "SELECT name, phone FROM contacts";
        try (Connection conn = DBHelper.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add(new Contact(rs.getString("name"), rs.getString("phone")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            logger.log(Level.SEVERE, "Error retrieving contacts", e);
        }
        return list;
    }

    public static boolean isDuplicate(String name) {
        String sql = "SELECT name FROM contacts WHERE name = ?";
        try (Connection conn = DBHelper.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            ResultSet rs = pstmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static List<Contact> sortByName(List<Contact> contacts) {
        contacts.sort(Comparator.comparing(Contact::getName, String.CASE_INSENSITIVE_ORDER));
        return contacts;
    }

    public static List<Contact> sortByPhone(List<Contact> contacts) {
        contacts.sort(Comparator.comparing(Contact::getPhone));
        return contacts;
    }

    public static void saveToFile() {
        List<Contact> contacts = getAllContacts();
        File file = new File(FILE_PATH);
        file.getParentFile().mkdirs(); // Ensure data/ folder exists

        try (PrintWriter writer = new PrintWriter(new FileWriter(file))) {
            for (Contact c : contacts) {
                writer.println(c.getName() + "," + c.getPhone());
            }
            System.out.println("Contacts saved to file.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
