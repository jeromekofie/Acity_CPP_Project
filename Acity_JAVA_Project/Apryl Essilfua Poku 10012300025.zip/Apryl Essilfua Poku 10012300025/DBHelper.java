import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DBHelper {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/mydatabase";  // Corrected to DB_URL
    private static final String USER = "root";
    private static final String PASSWORD = "aprylp123";

    // Method to establish and return a database connection
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, USER, PASSWORD);  // Fixed: Added USER and PASSWORD
    }

    // Method to initialize the database (create table if not exists)
    public static void initDB() {
        String sql = "CREATE TABLE IF NOT EXISTS contacts (" +
                     "name VARCHAR(255) PRIMARY KEY, " +  // Fixed: Changed TEXT to VARCHAR for MySQL compatibility
                     "phone VARCHAR(255) NOT NULL)";      // Fixed: Changed TEXT to VARCHAR for MySQL compatibility

        try (Connection conn = getConnection(); 
             Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
            System.out.println("Database initialized.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
