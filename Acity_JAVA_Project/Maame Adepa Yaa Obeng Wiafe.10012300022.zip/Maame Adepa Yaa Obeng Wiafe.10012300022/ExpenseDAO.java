import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ExpenseDAO {
    
    // Create the expenses table if it doesn't exist
    public static void createTable() {
        String createTableSQL = "IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='expenses' AND xtype='U') "
                + "CREATE TABLE expenses ("
                + "id INT IDENTITY(1,1) PRIMARY KEY, "
                + "date DATE, "
                + "amount DECIMAL(10,2), "
                + "category VARCHAR(50), "
                + "description VARCHAR(255))";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.execute(createTableSQL);
            System.out.println("Expenses table created or already exists.");
            
            // Verify table exists
            ResultSet rs = stmt.executeQuery("SELECT COUNT(*) as count FROM expenses");
            if (rs.next()) {
                System.out.println("Current number of records in expenses table: " + rs.getInt("count"));
            }
        } catch (SQLException e) {
            System.err.println("Error creating expenses table.");
            e.printStackTrace();
        }
    }
    
    // Add a new expense
    public static boolean addExpense(Expense expense) {
        String sql = "INSERT INTO expenses (date, amount, category, description) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setDate(1, Date.valueOf(expense.getDate()));
            pstmt.setDouble(2, expense.getAmount());
            pstmt.setString(3, expense.getCategory().toString());
            pstmt.setString(4, expense.getDescription());
            
            System.out.println("Attempting to add expense: " + expense.toString());
            int rowsAffected = pstmt.executeUpdate();
            System.out.println("Rows affected by insert: " + rowsAffected);
            
            // Verify the insert
            try (Statement stmt = conn.createStatement()) {
                ResultSet rs = stmt.executeQuery("SELECT TOP 1 * FROM expenses ORDER BY id DESC");
                if (rs.next()) {
                    System.out.println("Last inserted record: ID=" + rs.getInt("id") + 
                                     ", Amount=" + rs.getDouble("amount") + 
                                     ", Category=" + rs.getString("category") + 
                                     ", Description=" + rs.getString("description"));
                }
            }
            
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("Error adding expense to database.");
            e.printStackTrace();
            return false;
        }
    }
    
    // Delete an expense
    public static boolean deleteExpense(int id) {
        String sql = "DELETE FROM expenses WHERE id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            System.out.println("Attempting to delete expense with ID: " + id);
            int rowsAffected = pstmt.executeUpdate();
            System.out.println("Rows affected by delete: " + rowsAffected);
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("Error deleting expense from database.");
            e.printStackTrace();
            return false;
        }
    }
    
    // Get all expenses
    public static List<Expense> getAllExpenses() {
        List<Expense> expenses = new ArrayList<>();
        String sql = "SELECT * FROM expenses ORDER BY date DESC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            System.out.println("Retrieving all expenses from database:");
            while (rs.next()) {
                Expense expense = new Expense(
                    rs.getDouble("amount"),
                    ExpenseCategory.valueOf(rs.getString("category")),
                    rs.getString("description"),
                    rs.getDate("date").toLocalDate()
                );
                expenses.add(expense);
                System.out.println("Found expense: " + expense.toString());
            }
            System.out.println("Total expenses retrieved: " + expenses.size());
            
        } catch (SQLException e) {
            System.err.println("Error retrieving expenses from database.");
            e.printStackTrace();
        }
        
        return expenses;
    }
    
    // Get monthly expenses
    public static double getMonthlyExpenses(int year, int month) {
        String sql = "SELECT SUM(amount) as total FROM expenses WHERE YEAR(date) = ? AND MONTH(date) = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, year);
            pstmt.setInt(2, month);
            
            System.out.println("Calculating monthly expenses for " + month + "/" + year);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    double total = rs.getDouble("total");
                    System.out.println("Monthly total: $" + total);
                    return total;
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error calculating monthly expenses.");
            e.printStackTrace();
        }
        
        return 0.0;
    }
    
    // Get yearly expenses
    public static double getYearlyExpenses(int year) {
        String sql = "SELECT SUM(amount) as total FROM expenses WHERE YEAR(date) = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, year);
            
            System.out.println("Calculating yearly expenses for " + year);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    double total = rs.getDouble("total");
                    System.out.println("Yearly total: $" + total);
                    return total;
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error calculating yearly expenses.");
            e.printStackTrace();
        }
        
        return 0.0;
    }
} 