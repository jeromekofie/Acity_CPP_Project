import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    private static final String DB_URL = "jdbc:sqlserver://localhost:1433;databaseName=ExpenseTracker;integratedSecurity=true;encrypt=true;trustServerCertificate=true";
    
    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            
            
            Connection conn = DriverManager.getConnection(DB_URL);
            System.out.println("Database connection established successfully.");
            return conn;
        } catch (ClassNotFoundException e) {
            System.err.println("SQL Server JDBC Driver not found.");
            throw new SQLException("JDBC Driver not found", e);
        }
    }

    public static void main(String[] args) {
        Connection conn = null;
        try {
            conn = getConnection();
            if (conn != null && !conn.isClosed()) {
                System.out.println("Database connection test successful!");
            }
        } catch (SQLException e) {
            System.err.println("Error testing database connection.");
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                    System.out.println("Database connection closed.");
                } catch (SQLException e) {
                    System.err.println("Error closing database connection.");
                    e.printStackTrace();
                }
            }
        }
    }
} 