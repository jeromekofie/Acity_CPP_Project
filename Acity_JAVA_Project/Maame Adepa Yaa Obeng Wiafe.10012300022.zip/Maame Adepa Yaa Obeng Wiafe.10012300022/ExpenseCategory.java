public enum ExpenseCategory {
    FOOD,
    TRANSPORT,
    ENTERTAINMENT,
    UTILITIES,
    SHOPPING,
    HEALTHCARE,
    OTHER
} 