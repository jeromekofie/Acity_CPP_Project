import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ExpenseManager {
    private List<Expense> expenses;

    public ExpenseManager() {
        // Initialize with empty list instead of loading from database
        this.expenses = new ArrayList<>();
    }

    // Add a new expense
    public void addExpense(double amount, ExpenseCategory category, String description) {
        Expense expense = new Expense(amount, category, description, LocalDate.now());
        expenses.add(expense);
    }

    // Delete an expense
    public boolean deleteExpense(int index) {
        if (index >= 0 && index < expenses.size()) {
            expenses.remove(index);
            return true;
        }
        return false;
    }

    // Calculate total expenses for a specific month and year
    public double getMonthlyExpenses(int year, int month) {
        YearMonth yearMonth = YearMonth.of(year, month);
        return expenses.stream()
                .filter(e -> YearMonth.from(e.getDate()).equals(yearMonth))
                .mapToDouble(Expense::getAmount)
                .sum();
    }

    // Calculate total expenses for a specific year
    public double getYearlyExpenses(int year) {
        return expenses.stream()
                .filter(e -> e.getDate().getYear() == year)
                .mapToDouble(Expense::getAmount)
                .sum();
    }

    // Get expenses by category for a specific month
    public Map<ExpenseCategory, Double> getMonthlyExpensesByCategory(int year, int month) {
        YearMonth yearMonth = YearMonth.of(year, month);
        return expenses.stream()
                .filter(e -> YearMonth.from(e.getDate()).equals(yearMonth))
                .collect(Collectors.groupingBy(
                        Expense::getCategory,
                        Collectors.summingDouble(Expense::getAmount)
                ));
    }

    // Get all expenses
    public List<Expense> getAllExpenses() {
        return expenses;
    }
} 