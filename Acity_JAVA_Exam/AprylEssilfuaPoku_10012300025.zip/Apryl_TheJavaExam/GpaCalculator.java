//APRYL ESSILFUA POKU ||10012300025|| INFORMATION TECHNOLOGY ||L200

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class GpaCalculator extends JFrame{
    private JTextField nameField, idField, courseField, num1Field, num2Field; //all fields
    private DefaultTableModel tableModel;
    private JTable table;
    private final String filePath = "gpa_records.txt"; //filestorage

    public GpaCalculator(){
        setTitle("GPA Calculator Application");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);

        // first set the GUI Components
        nameField = new JTextField(10); //Student Name
        idField = new JTextField(10); //StudentID
        courseField = new JTextField(10); //Courses
        num1Field = new JTextField(5); //SUM OF ALL GRADE POINTS
        num2Field = new JTextField(5); //SUM OF ALL CREDIT HOURS

        //for the CRUD FUNCTIONS - ADDED Buttons
        JButton addBtn = new JButton("Add");
        JButton updateBtn = new JButton("Update");
        JButton deleteBtn = new JButton("Delete"); 
      //JComboBox storageBtn || dont remember :(

        // Table and Panels
        tableModel = new DefaultTableModel(new String[]{"Student Name", "ID", "Courses", "Sum of Grade Point", "Sum of Credit Hours", "GPA"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        JPanel inputPanel = new JPanel();
        inputPanel.add(new JLabel("Student Name:"));
        inputPanel.add(nameField);
        inputPanel.add(new JLabel("ID:"));
        inputPanel.add(idField);
        inputPanel.add(new JLabel("Course:"));
        inputPanel.add(courseField);
        inputPanel.add(new JLabel("Sum of Grade Points:"));
        inputPanel.add(num1Field);
        inputPanel.add(new JLabel("Sum of Credit Hours:"));
        inputPanel.add(num2Field);
        inputPanel.add(addBtn);
        inputPanel.add(updateBtn);
        inputPanel.add(deleteBtn);

        add(inputPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        // LoadIng data from the file
        loadFromFile();

        //functionalities of buttons
        addBtn.addActionListener(e -> addEntry());
        updateBtn.addActionListener(e -> updateEntry());
        deleteBtn.addActionListener(e -> deleteEntry());
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                nameField.setText(tableModel.getValueAt(row, 0).toString());
                idField.setText(tableModel.getValueAt(row, 1).toString());
                courseField.setText(tableModel.getValueAt(row, 2).toString());
                num1Field.setText(tableModel.getValueAt(row, 3).toString());
                num2Field.setText(tableModel.getValueAt(row, 4).toString());
            }
        });
    }

    private void addEntry() {
        String name = nameField.getText().trim();
        String id = idField.getText().trim();
        String courses = courseField.getText().trim();
        double num1, num2;
        try {
            num1 = Double.parseDouble(num1Field.getText().trim());
            num2 = Double.parseDouble(num2Field.getText().trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Enter valid numbers.");
            return;
        }

        double gpa = num1*num2 / num2;
        tableModel.addRow(new Object[]{name, id, courses, num1, num2, gpa});
        saveToFile();
        clearFields();
    }

    private void updateEntry() {
        int row = table.getSelectedRow();
        if (row == -1) return;

        String name = nameField.getText().trim();
        String id = idField.getText().trim();
        String courses = courseField.getText().trim();
        double num1, num2;
        try {
            num1 = Double.parseDouble(num1Field.getText().trim());
            num2 = Double.parseDouble(num2Field.getText().trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Enter valid numbers.");
            return;
        }

        double gpa = num1*num2 / num2;
        tableModel.setValueAt(name, row, 0);
        tableModel.setValueAt(id,row, 1);
        tableModel.setValueAt(courses, row, 2);
        tableModel.setValueAt(num1, row, 3);
        tableModel.setValueAt(num2, row, 4);
        tableModel.setValueAt(gpa, row, 5);
        saveToFile();
        clearFields();
    }

    private void deleteEntry() {
        int row = table.getSelectedRow();
        if (row != -1) {
            tableModel.removeRow(row);
            saveToFile();
            clearFields();
        }
    }

    private void loadFromFile() {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            tableModel.setRowCount(0);
            String line;
            while ((line = reader.readLine()) != null) {
                tableModel.addRow(line.split("|"));
            }
        } catch (IOException ignored) {
        }
    }

    private void saveToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                writer.write(String.format("%s,%s,%s,%s,%s,%s\n",
                        tableModel.getValueAt(i, 0),
                        tableModel.getValueAt(i, 1),
                        tableModel.getValueAt(i, 2),
                        tableModel.getValueAt(i, 3),
                        tableModel.getValueAt(i,4),
                        tableModel.getValueAt(i,5)));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void clearFields() {
        nameField.setText("");
        idField.setText("");
        courseField.setText("");
        num1Field.setText("");
        num2Field.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new GpaCalculator().setVisible(true));

    }
}
